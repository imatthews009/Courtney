const tsrStartManifest = () => ({ "routes": { "__root__": { "filePath": "/Users/ianmatthews/Courtney/src/routes/__root.tsx", "children": ["/", "/test"], "preloads": ["/assets/main-DQOOd1nB.js"], "assets": [] }, "/": { "filePath": "/Users/ianmatthews/Courtney/src/routes/index.tsx" }, "/test": { "filePath": "/Users/ianmatthews/Courtney/src/routes/test.tsx" } }, "clientEntry": "/assets/main-DQOOd1nB.js" });

export { tsrStartManifest };
//# sourceMappingURL=_tanstack-start-manifest_v-b_szcZib.mjs.map
