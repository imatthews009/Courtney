const _tanstackStartServerFnManifest_v = {};

export { _tanstackStartServerFnManifest_v as default };
//# sourceMappingURL=_tanstack-start-server-fn-manifest_v-DtgTK7xl.mjs.map
