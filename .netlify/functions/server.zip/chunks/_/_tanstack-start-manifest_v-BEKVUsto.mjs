const tsrStartManifest = () => ({ "routes": { "__root__": { "filePath": "/Users/ianmatthews/Courtney/src/routes/__root.tsx", "children": ["/", "/test"], "preloads": ["/assets/main-DNZZ-PP3.js"], "assets": [] }, "/": { "filePath": "/Users/ianmatthews/Courtney/src/routes/index.tsx", "assets": [], "preloads": ["/assets/index-CTUYJr-U.js", "/assets/CourtneyCarousel-BTmDuQEf.js"] }, "/test": { "filePath": "/Users/ianmatthews/Courtney/src/routes/test.tsx", "assets": [], "preloads": ["/assets/test-C8HSfhvU.js", "/assets/CourtneyCarousel-BTmDuQEf.js"] } }, "clientEntry": "/assets/main-DNZZ-PP3.js" });

export { tsrStartManifest };
//# sourceMappingURL=_tanstack-start-manifest_v-BEKVUsto.mjs.map
